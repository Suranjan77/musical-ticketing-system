package org.musical.ticketing.util;

/**
 * @author suranjanpoudel
 */
public class PanelIds {

  public static final String BROWSE_PANEL_ID = "BROWSE_PANEL_ID";
  public static final String MUSICAL_DETAILS_PANEL_ID = "MUSICAL_DETAILS_PANEL_ID";
  public static final String RECEIPT_PANEL_ID = "RECEIPT_PANEL_ID";
  public static final String START_PANEL_ID = "START_PANEL_ID";
}
