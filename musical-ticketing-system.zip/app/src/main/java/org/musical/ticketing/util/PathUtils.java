package org.musical.ticketing.util;

public class PathUtils {

  public static final String ROOT_PATH =
      System.getProperty("user.home") + "/musical_ticketing_system";
}
