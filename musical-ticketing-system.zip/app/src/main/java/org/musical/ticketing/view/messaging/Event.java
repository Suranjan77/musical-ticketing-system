package org.musical.ticketing.view.messaging;

// Market interface
public interface Event {
}
