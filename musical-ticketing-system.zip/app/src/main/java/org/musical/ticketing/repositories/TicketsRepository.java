package org.musical.ticketing.repositories;

import org.musical.ticketing.domain.Ticket;

public class TicketsRepository implements DomainRepository<Ticket> {}
