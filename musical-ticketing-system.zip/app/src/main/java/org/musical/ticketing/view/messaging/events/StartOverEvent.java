package org.musical.ticketing.view.messaging.events;

import org.musical.ticketing.view.messaging.Event;

/**
 *
 * @author suranjanpoudel
 */
public class StartOverEvent implements Event {

}
